({
  name: "Mud Bath",
  rating: 4.5,
  num: -1001,
  flags: { breakable: 1 },

  onModifyDef(def, pokemon, attacker, move) {
    if (move && move.category === "Physical") return this.chainModify(2);
  },

  onModifySpD(spd, pokemon, attacker, move) {
    if (move && move.category === "Special") return this.chainModify(2);
  },

  onBasePower(basePower, attacker, defender, move) {
    if (move && move.type === "Ground") return this.chainModify(1.5);
  },

  onResidual(pokemon) {
    this.heal(pokemon.baseMaxhp / 8, pokemon);
  }
})