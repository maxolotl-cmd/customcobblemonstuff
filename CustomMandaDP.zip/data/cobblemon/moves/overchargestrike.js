({
  desc: "A heavy electric blow that overcharges the user. Hits an adjacent foe for chip damage.",
  shortDesc: "30% para. Charges user. Chips adjacent foe.",
  num: 9003,
  accuracy: 95,
  basePower: 110,
  category: "Special",
  name: "Overcharge Strike",
  pp: 10,
  priority: 0,
  flags: { protect: 1, mirror: 1 },

  secondary: {
    chance: 30,
    status: "par"
  },


  onHit(target, source) {
    const side = target.side;
    for (const other of side.active) {
      if (!other || other === target || other.fainted) continue;
      if (!this.isAdjacent(target, other)) continue;

      if (other.hasType && other.hasType('Ground')) continue;

      this.damage(other.baseMaxhp / 10, other, source);
    }
  },

  target: "normal",
  type: "Electric",
  contestType: "Cool"
})